<template>
  <div class="min-h-screen bg-[#eef3f2]">

    <!-- ===================================================== -->
    <!-- CABECERA                                             -->
    <!-- ===================================================== -->

    <header
      class="bg-[#12574c] text-white border-b border-white/10"
    >
      <div
        class="max-w-7xl mx-auto px-6 py-5
               flex items-center justify-between gap-4"
      >
        <div>
          <p
            class="text-[10px] uppercase tracking-[0.18em]
                   font-black text-emerald-200"
          >
            Panel del Supervisor
          </p>

          <h1
            class="text-2xl font-black mt-1"
          >
            Postulantes disponibles
          </h1>

          <p
            class="text-xs text-emerald-100/80 mt-1"
          >
            Candidatos aprobados por Talento Humano
            compatibles con los requerimientos de su área.
          </p>
        </div>

        <NuxtLink
          to="/supervisor/dashboard"
          class="px-4 py-2.5 rounded-xl
                 border border-white/20
                 bg-white/10 hover:bg-white/15
                 text-xs font-bold transition"
        >
          Volver al Dashboard
        </NuxtLink>
      </div>
    </header>


    <!-- ===================================================== -->
    <!-- CONTENIDO                                            -->
    <!-- ===================================================== -->

    <main
      class="max-w-7xl mx-auto px-6 py-7"
    >

      <!-- CARGANDO -->

      <div
        v-if="cargando"
        class="bg-white border border-slate-200
               rounded-2xl p-10 text-center shadow-sm"
      >
        <div
          class="w-9 h-9 mx-auto rounded-full
                 border-4 border-slate-200
                 border-t-[#12574c]
                 animate-spin"
        />

        <p
          class="text-sm font-bold text-slate-600 mt-4"
        >
          Cargando postulantes disponibles...
        </p>
      </div>


      <!-- ERROR -->

      <div
        v-else-if="errorMensaje"
        class="bg-red-50 border border-red-200
               rounded-2xl p-5"
      >
        <p
          class="text-sm font-black text-red-700"
        >
          No fue posible cargar los postulantes
        </p>

        <p
          class="text-xs text-red-600 mt-1"
        >
          {{ errorMensaje }}
        </p>

        <button
          type="button"
          class="mt-4 px-4 py-2 rounded-lg
                 bg-red-600 hover:bg-red-700
                 text-white text-xs font-bold"
          @click="cargarPostulantes"
        >
          Intentar nuevamente
        </button>
      </div>


      <template v-else>

        <!-- ================================================= -->
        <!-- DEPARTAMENTO                                     -->
        <!-- ================================================= -->

        <section
          class="bg-white rounded-2xl
                 border border-slate-200
                 shadow-sm p-5 mb-5"
        >
          <div
            class="flex flex-wrap items-center
                   justify-between gap-4"
          >
            <div>
              <p
                class="text-[9px] uppercase tracking-widest
                       font-black text-emerald-700"
              >
                Área asignada
              </p>

              <h2
                class="text-lg font-black text-slate-800 mt-1"
              >
                {{
                  datos.departamento?.nombre ||
                  'Departamento'
                }}
              </h2>

              <p
                class="text-xs text-slate-500 mt-1"
              >
                {{
                  datos.departamento?.gerencia?.nombre ||
                  'Gerencia no registrada'
                }}
              </p>
            </div>

            <div
              class="px-4 py-2 rounded-xl
                     bg-emerald-50
                     border border-emerald-200"
            >
              <span
                class="text-[9px] font-black
                       text-emerald-700 uppercase"
              >
                Supervisor autorizado
              </span>
            </div>
          </div>
        </section>


        <!-- ================================================= -->
        <!-- INDICADORES                                      -->
        <!-- ================================================= -->

        <section
          class="grid grid-cols-1 md:grid-cols-3
                 gap-4 mb-5"
        >
          <article
            class="bg-white border border-slate-200
                   rounded-2xl p-5 shadow-sm"
          >
            <p
              class="text-[9px] uppercase
                     tracking-widest font-black
                     text-slate-400"
            >
              Postulantes disponibles
            </p>

            <strong
              class="block text-3xl font-black
                     text-[#12574c] mt-2"
            >
              {{ datos.total_postulantes || 0 }}
            </strong>

            <p
              class="text-xs text-slate-500 mt-1"
            >
              Aprobados por RRHH
            </p>
          </article>


          <article
            class="bg-white border border-slate-200
                   rounded-2xl p-5 shadow-sm"
          >
            <p
              class="text-[9px] uppercase
                     tracking-widest font-black
                     text-slate-400"
            >
              Requerimientos abiertos
            </p>

            <strong
              class="block text-3xl font-black
                     text-[#12574c] mt-2"
            >
              {{
                datos.total_solicitudes_abiertas ||
                0
              }}
            </strong>

            <p
              class="text-xs text-slate-500 mt-1"
            >
              Solicitudes del Departamento
            </p>
          </article>


          <article
            class="bg-white border border-slate-200
                   rounded-2xl p-5 shadow-sm"
          >
            <p
              class="text-[9px] uppercase
                     tracking-widest font-black
                     text-slate-400"
            >
              Cupos disponibles
            </p>

            <strong
              class="block text-3xl font-black
                     text-[#12574c] mt-2"
            >
              {{ totalCuposDisponibles }}
            </strong>

            <p
              class="text-xs text-slate-500 mt-1"
            >
              Según requerimientos vigentes
            </p>
          </article>
        </section>


        <!-- ================================================= -->
        <!-- FILTROS                                          -->
        <!-- ================================================= -->

        <section
          class="bg-white border border-slate-200
                 rounded-2xl shadow-sm p-4 mb-5"
        >
          <div
            class="grid grid-cols-1 md:grid-cols-3 gap-3"
          >
            <div class="md:col-span-2">
              <label
                class="block text-[9px] uppercase
                       tracking-widest font-black
                       text-slate-500 mb-1.5"
              >
                Buscar postulante
              </label>

              <input
                v-model="busqueda"
                type="text"
                placeholder="Nombre, C.I., carrera o institución..."
                class="w-full px-4 py-3
                       border border-slate-200
                       rounded-xl bg-slate-50
                       text-sm text-slate-700
                       focus:outline-none
                       focus:ring-2
                       focus:ring-[#12574c]/20
                       focus:border-[#12574c]"
              >
            </div>


            <div>
              <label
                class="block text-[9px] uppercase
                       tracking-widest font-black
                       text-slate-500 mb-1.5"
              >
                Turno
              </label>

              <select
                v-model="filtroTurno"
                class="w-full px-4 py-3
                       border border-slate-200
                       rounded-xl bg-slate-50
                       text-sm text-slate-700
                       focus:outline-none
                       focus:ring-2
                       focus:ring-[#12574c]/20"
              >
                <option value="">
                  Todos
                </option>

                <option value="MANANA">
                  Mañana
                </option>

                <option value="TARDE">
                  Tarde
                </option>

                <option value="TIEMPO_COMPLETO">
                  Tiempo completo
                </option>
              </select>
            </div>
          </div>
        </section>


        <!-- ================================================= -->
        <!-- SIN REQUERIMIENTOS                               -->
        <!-- ================================================= -->

        <section
          v-if="
            datos.total_solicitudes_abiertas === 0
          "
          class="bg-white border border-slate-200
                 rounded-2xl p-10 text-center shadow-sm"
        >
          <div
            class="w-14 h-14 mx-auto
                   bg-slate-100 rounded-2xl
                   flex items-center justify-center"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              class="w-7 h-7 text-slate-400"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M9 12h6m-6 4h6M9 8h6M5 3h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2z"
              />
            </svg>
          </div>

          <h3
            class="text-base font-black
                   text-slate-700 mt-4"
          >
            No existen requerimientos abiertos
          </h3>

          <p
            class="text-xs text-slate-500
                   mt-2 max-w-lg mx-auto"
          >
            Actualmente su Departamento no cuenta con
            solicitudes de pasantes pendientes de cubrir.
          </p>
        </section>


        <!-- ================================================= -->
        <!-- SIN CANDIDATOS                                   -->
        <!-- ================================================= -->

        <section
          v-else-if="
            postulantesFiltrados.length === 0
          "
          class="bg-white border border-slate-200
                 rounded-2xl p-10 text-center shadow-sm"
        >
          <h3
            class="text-base font-black text-slate-700"
          >
            No hay postulantes disponibles
          </h3>

          <p
            class="text-xs text-slate-500 mt-2"
          >
            No existen candidatos aprobados que coincidan
            actualmente con los requerimientos del área.
          </p>
        </section>


        <!-- ================================================= -->
        <!-- TABLA                                            -->
        <!-- ================================================= -->

        <section
          v-else
          class="bg-white border border-slate-200
                 rounded-2xl shadow-sm overflow-hidden"
        >
          <div
            class="px-5 py-4 border-b border-slate-100
                   flex items-center justify-between"
          >
            <div>
              <p
                class="text-[9px] uppercase tracking-widest
                       font-black text-emerald-700"
              >
                Selección de candidatos
              </p>

              <h2
                class="text-base font-black text-slate-800"
              >
                Postulantes compatibles
              </h2>
            </div>

            <span
              class="px-3 py-1.5 rounded-full
                     bg-slate-100 text-slate-600
                     text-[9px] font-black"
            >
              {{ postulantesFiltrados.length }}
              resultado(s)
            </span>
          </div>


          <div class="overflow-x-auto">

            <table class="w-full">

              <thead class="bg-slate-50">

                <tr>

                  <th
                    class="px-5 py-3 text-left
                           text-[9px] uppercase
                           tracking-wider text-slate-500"
                  >
                    Postulante
                  </th>

                  <th
                    class="px-5 py-3 text-left
                           text-[9px] uppercase
                           tracking-wider text-slate-500"
                  >
                    Formación
                  </th>

                  <th
                    class="px-5 py-3 text-left
                           text-[9px] uppercase
                           tracking-wider text-slate-500"
                  >
                    Turno
                  </th>

                  <th
                    class="px-5 py-3 text-left
                           text-[9px] uppercase
                           tracking-wider text-slate-500"
                  >
                    Estado
                  </th>

                  <th
                    class="px-5 py-3 text-right
                           text-[9px] uppercase
                           tracking-wider text-slate-500"
                  >
                    Acción
                  </th>

                </tr>

              </thead>


              <tbody
                class="divide-y divide-slate-100"
              >

                <tr
                  v-for="
                    postulante
                    in postulantesFiltrados
                  "
                  :key="postulante.postulacion_id"
                  class="hover:bg-slate-50/70 transition"
                >

                  <!-- PERSONA -->

                  <td class="px-5 py-4">

                    <div
                      class="flex items-center gap-3"
                    >

                      <div
                        class="w-10 h-10 rounded-xl
                               bg-emerald-50
                               border border-emerald-100
                               flex items-center
                               justify-center
                               text-xs font-black
                               text-[#12574c]"
                      >
                        {{
                          obtenerIniciales(
                            postulante,
                          )
                        }}
                      </div>

                      <div>

                        <p
                          class="text-xs font-black
                                 text-slate-800"
                        >
                          {{
                            postulante
                              .nombre_completo
                          }}
                        </p>

                        <p
                          class="text-[10px]
                                 text-slate-500 mt-1"
                        >
                          C.I.
                          {{ postulante.ci }}
                          {{ postulante.expedido }}
                        </p>

                        <span
                          v-if="
                            postulante
                              .es_repostulacion
                          "
                          class="inline-block mt-1
                                 px-2 py-0.5
                                 rounded-full
                                 bg-amber-50
                                 border border-amber-200
                                 text-[8px]
                                 font-black
                                 text-amber-700"
                        >
                          Repostulación
                          #{{ postulante.numero_intento }}
                        </span>

                      </div>

                    </div>

                  </td>


                  <!-- FORMACIÓN -->

                  <td class="px-5 py-4">

                    <template
                      v-if="
                        postulante.formacion?.length
                      "
                    >
                      <p
                        class="text-xs font-bold
                               text-slate-700"
                      >
                        {{
                          postulante
                            .formacion[0]
                            .carrera
                        }}
                      </p>

                      <p
                        class="text-[10px]
                               text-slate-500 mt-1"
                      >
                        {{
                          postulante
                            .formacion[0]
                            .institucion_nombre
                        }}
                      </p>
                    </template>

                    <span
                      v-else
                      class="text-xs text-slate-400"
                    >
                      Sin información
                    </span>

                  </td>


                  <!-- TURNO -->

                  <td class="px-5 py-4">

                    <span
                      class="text-xs font-bold
                             text-slate-600"
                    >
                      {{
                        formatearTurno(
                          postulante.turno,
                        )
                      }}
                    </span>

                  </td>


                  <!-- ESTADO -->

                  <td class="px-5 py-4">

                    <span
                      class="inline-flex
                             px-2.5 py-1
                             rounded-full
                             bg-emerald-50
                             border border-emerald-200
                             text-[8px]
                             font-black
                             text-emerald-700"
                    >
                      APROBADO RRHH
                    </span>

                  </td>


                  <!-- ACCIÓN -->

                  <td
                    class="px-5 py-4 text-right"
                  >

                    <button
                      type="button"
                      class="px-3.5 py-2
                             rounded-lg
                             bg-[#12574c]
                             hover:bg-[#0d463d]
                             text-white
                             text-[9px]
                             font-black
                             transition"
                      @click="
                        verPostulante(
                          postulante,
                        )
                      "
                    >
                      Ver perfil
                    </button>

                  </td>

                </tr>

              </tbody>

            </table>

          </div>

        </section>

      </template>

    </main>


    <!-- ===================================================== -->
    <!-- MODAL TEMPORAL                                       -->
    <!-- ===================================================== -->

    <div
      v-if="postulanteSeleccionado"
      class="fixed inset-0 z-50
             bg-slate-900/50
             backdrop-blur-sm
             flex items-center justify-center p-4"
      @click.self="cerrarModal"
    >
      <div
        class="bg-white w-full max-w-xl
               rounded-2xl shadow-2xl
               overflow-hidden"
      >

        <div
          class="px-5 py-4 bg-[#12574c]
                 text-white
                 flex items-center
                 justify-between gap-4"
        >
          <div>
            <p
              class="text-[9px] uppercase
                     tracking-widest
                     text-emerald-200 font-black"
            >
              Perfil del postulante
            </p>

            <h3
              class="font-black mt-1"
            >
              {{
                postulanteSeleccionado
                  .nombre_completo
              }}
            </h3>
          </div>

          <button
            type="button"
            class="w-8 h-8 rounded-full
                   bg-white/10 hover:bg-white/20
                   font-black"
            @click="cerrarModal"
          >
            ×
          </button>
        </div>


        <div class="p-5 space-y-4">

          <div
            class="grid grid-cols-2 gap-3"
          >

            <div class="info-box">
              <span>C.I.</span>
              <strong>
                {{ postulanteSeleccionado.ci }}
                {{ postulanteSeleccionado.expedido }}
              </strong>
            </div>

            <div class="info-box">
              <span>Celular</span>
              <strong>
                {{
                  postulanteSeleccionado.celular ||
                  'No registrado'
                }}
              </strong>
            </div>

            <div class="info-box">
              <span>Correo</span>
              <strong>
                {{
                  postulanteSeleccionado.email ||
                  'No registrado'
                }}
              </strong>
            </div>

            <div class="info-box">
              <span>Turno</span>
              <strong>
                {{
                  formatearTurno(
                    postulanteSeleccionado.turno,
                  )
                }}
              </strong>
            </div>

          </div>


          <div
            v-if="
              postulanteSeleccionado
                .formacion?.length
            "
            class="p-4 rounded-xl
                   bg-slate-50
                   border border-slate-200"
          >
            <p
              class="text-[9px] uppercase
                     tracking-widest
                     font-black text-slate-400"
            >
              Formación académica
            </p>

            <div
              v-for="
                formacion
                in postulanteSeleccionado.formacion
              "
              :key="formacion.id"
              class="mt-3"
            >
              <p
                class="text-xs font-black
                       text-slate-700"
              >
                {{ formacion.carrera }}
              </p>

              <p
                class="text-[10px]
                       text-slate-500 mt-1"
              >
                {{ formacion.institucion_nombre }}
                ·
                {{ formacion.semestre_o_nivel }}
              </p>
            </div>
          </div>


          <div
            class="p-4 rounded-xl
                   bg-emerald-50
                   border border-emerald-200"
          >
            <p
              class="text-[9px] uppercase
                     tracking-widest font-black
                     text-emerald-700"
            >
              Requerimientos compatibles
            </p>

            <div
              v-for="
                solicitud
                in postulanteSeleccionado
                  .solicitudes_compatibles
              "
              :key="solicitud.solicitud_id"
              class="mt-3"
            >
              <p
                class="text-xs font-black
                       text-slate-700"
              >
                {{ solicitud.carrera }}
              </p>

              <p
                class="text-[10px]
                       text-slate-500 mt-1"
              >
                Cupos disponibles:
                {{ solicitud.cupos_disponibles }}
              </p>
            </div>
          </div>


          <p
            class="text-[10px] text-slate-500
                   leading-relaxed"
          >
            En el siguiente paso incorporaremos la
            visualización de documentos, CV e historial
            académico y posteriormente la acción de selección.
          </p>

        </div>

      </div>
    </div>

  </div>
</template>


<script setup>
import {
  computed,
  onMounted,
  ref,
} from 'vue'


definePageMeta({
  middleware: 'supervisor',
})


const { $api } =
  useNuxtApp()


const cargando =
  ref(true)


const errorMensaje =
  ref('')


const busqueda =
  ref('')


const filtroTurno =
  ref('')


const postulanteSeleccionado =
  ref(null)


const datos =
  ref({

    departamento:
      null,

    total_solicitudes_abiertas:
      0,

    total_postulantes:
      0,

    solicitudes:
      [],

    postulantes:
      [],

  })


const totalCuposDisponibles =
  computed(() => {

    return (
      datos.value
        .solicitudes || []
    )
      .reduce(
        (
          total,
          solicitud,
        ) => {

          return (
            total +
            Number(
              solicitud
                .cupos_disponibles ||
              0,
            )
          )

        },
        0,
      )

  })


const postulantesFiltrados =
  computed(() => {

    const texto =
      busqueda.value
        .trim()
        .toLowerCase()


    return (
      datos.value
        .postulantes || []
    )
      .filter(
        postulante => {

          if (
            filtroTurno.value &&
            postulante.turno !==
              filtroTurno.value
          ) {

            return false

          }


          if (!texto) {
            return true
          }


          const formacion =
            (
              postulante.formacion ||
              []
            )
              .map(
                item =>
                  `${
                    item.carrera || ''
                  } ${
                    item.institucion_nombre ||
                    ''
                  }`,
              )
              .join(' ')


          const contenido =
            `
              ${postulante.nombre_completo || ''}
              ${postulante.ci || ''}
              ${formacion}
            `
              .toLowerCase()


          return contenido.includes(
            texto,
          )

        },
      )

  })


const cargarPostulantes =
  async () => {

    cargando.value =
      true

    errorMensaje.value =
      ''


    try {

      const respuesta =
        await $api(
          '/supervisor/postulantes',
        )


      datos.value = {

        departamento:
          respuesta?.departamento ??
          null,

        total_solicitudes_abiertas:
          respuesta
            ?.total_solicitudes_abiertas ??
          0,

        total_postulantes:
          respuesta
            ?.total_postulantes ??
          0,

        solicitudes:
          respuesta?.solicitudes ??
          [],

        postulantes:
          respuesta?.postulantes ??
          [],

      }

    } catch (error) {

      const mensajeServidor =
        Array.isArray(
          error?.data?.message,
        )
          ? error.data.message.join(
              ', ',
            )
          : error?.data?.message


      errorMensaje.value =
        mensajeServidor ||
        error?.message ||
        'Ocurrió un error al consultar los postulantes.'

    } finally {

      cargando.value =
        false

    }

  }


const obtenerIniciales =
  postulante => {

    const nombre =
      String(
        postulante.nombres ||
        '',
      )
        .trim()
        .charAt(0)


    const apellido =
      String(
        postulante.apellido_paterno ||
        '',
      )
        .trim()
        .charAt(0)


    return (
      `${nombre}${apellido}`
        .toUpperCase() ||
      'P'
    )

  }


const formatearTurno =
  turno => {

    const nombres = {

      MANANA:
        'Mañana',

      TARDE:
        'Tarde',

      TIEMPO_COMPLETO:
        'Tiempo completo',

    }


    return (
      nombres[turno] ||
      'No registrado'
    )

  }


const verPostulante =
  postulante => {

    postulanteSeleccionado.value =
      postulante

  }


const cerrarModal =
  () => {

    postulanteSeleccionado.value =
      null

  }


onMounted(
  cargarPostulantes,
)
</script>


<style scoped>
.info-box {
  padding: 12px;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  background: #f8fafc;
}

.info-box span {
  display: block;
  margin-bottom: 4px;
  color: #94a3b8;
  font-size: 8px;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.info-box strong {
  color: #475569;
  font-size: 10px;
  font-weight: 800;
  word-break: break-word;
}
</style>